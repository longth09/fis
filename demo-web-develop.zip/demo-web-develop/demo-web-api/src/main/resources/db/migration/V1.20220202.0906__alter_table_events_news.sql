alter table events_news add column type VARCHAR(20) NULL
;