alter table events add column `list_speaker_id` varchar(200) NULL
;