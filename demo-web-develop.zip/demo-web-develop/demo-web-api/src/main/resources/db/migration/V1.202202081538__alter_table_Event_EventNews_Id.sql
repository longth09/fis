alter table `Event_Event_News` add column id BIGINT NOT NULL
;
alter table `Event_event_news` add constraint een_pk primary key (id);