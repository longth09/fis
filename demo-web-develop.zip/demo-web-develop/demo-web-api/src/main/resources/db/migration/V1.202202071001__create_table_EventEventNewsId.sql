DROP TABLE IF EXISTS `Event_Event_News`;

CREATE TABLE Event_Event_News
(
    `event_id`       BIGINT NULL,
    `event_news_id`    BIGINT NULL

);