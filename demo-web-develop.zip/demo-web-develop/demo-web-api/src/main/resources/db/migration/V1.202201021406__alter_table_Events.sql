alter table events
    add unique (name
        )
;
