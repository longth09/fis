alter table account add column company_name varchar(500) null;
alter table account add column job_title varchar(500) null;
alter table account add column sector varchar(500) null;
alter table account add column country varchar(500) null;
alter table account add column interests varchar(500) null;