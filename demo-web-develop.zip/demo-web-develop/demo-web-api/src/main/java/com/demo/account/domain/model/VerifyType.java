package com.demo.account.domain.model;

public enum VerifyType {
    ACTIVE_ACCOUNT,
    RESET_PASSWORD
}
