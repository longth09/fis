package com.demo.shared.enumerate;

public enum EventNewsType {
    DEFAULT, THUMBNAIL;
}
