package com.demo.ticket.domain.model;

public enum TypeTicket {
    Type_A,Type_B,Type_C
}
