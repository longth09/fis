package com.demo.account.domain.model;

public enum RoleDefinition {
    ROLE_USER,
    ROLE_ADMIN
}
