package com.demo.shared.enumerate;

public enum AccountType {
    GOOGLE, FACEBOOK, LINE, NORMAL, TWITTER;
}
