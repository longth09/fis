package com.demo.shared.enumerate;

public enum Gender {
    MALE, FEMALE, OTHER;
}
