package com.demo.shared.enumerate;

public enum OrderStatus {
    PROCESSING, PAID, CANCELLED, FAILED, REFUNDED
}
