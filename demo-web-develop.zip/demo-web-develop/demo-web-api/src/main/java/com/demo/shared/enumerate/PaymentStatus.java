package com.demo.shared.enumerate;

public enum PaymentStatus {
    SUCCESS, FAIL, PROCESSING, CANCELED, REFUNDED
}
