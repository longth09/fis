package com.demo.account.domain.model;

public enum AuthProvider {
    local,
    facebook,
    google,
    github
}
