package com.demo.shared.enumerate;

public interface UrlConstant {
    String URL_API_FACEBOOK_GET_INFO = "https://graph.facebook.com/me?access_token=";
    String URL_API_LINE_GET_INFO = "https://api.line.me/v2/profile";
    String URL_API_TWITTER_GET_INFO = "https://api.twitter.com/2/users";
}
