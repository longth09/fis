package com.demo.shared.enumerate;

public enum TicketType {
    TYPE_A, TYPE_B, TYPE_C;
}
