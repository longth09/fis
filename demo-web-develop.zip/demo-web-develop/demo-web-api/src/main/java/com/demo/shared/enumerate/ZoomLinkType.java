package com.demo.shared.enumerate;

public enum ZoomLinkType {
    WEBINAR, MEETING
}
