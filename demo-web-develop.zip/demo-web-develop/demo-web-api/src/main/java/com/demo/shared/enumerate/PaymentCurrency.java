package com.demo.shared.enumerate;

public enum PaymentCurrency {
    HKD
}
