package com.demo.shared.enumerate;

public enum PaymentMethod {
    CARD, WECHAT, ALIPAY
}
