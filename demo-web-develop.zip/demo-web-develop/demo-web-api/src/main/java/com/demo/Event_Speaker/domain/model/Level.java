package com.demo.Event_Speaker.domain.model;

public enum Level {
    Master,Senior,Junior
}
