package com.demo.Event_News.domain.model;

public enum Type {
    A,B,C,D
}
