package com.demo;

import org.junit.Ignore;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@Ignore
@SpringBootTest
public class GlobalTest {
//    @Test
    public void contextLoad(){

    }
}
