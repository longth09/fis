#Ticketing backend api
## Getting Started

Require:

1. MySQL 5.7
2. Java 11
3. Maven version 3.6.x

> Default port: 9093 <br/>
> Spring Flyway included & start with App